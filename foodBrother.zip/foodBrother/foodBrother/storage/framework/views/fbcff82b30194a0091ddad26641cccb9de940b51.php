;
<?php $__env->startSection('content'); ?>;
<?php



?>
<div id="page-wrapper">
  <div class="container-fluid">
    <form class="form-horizontal" enctype="multipart/form-data" action="<?php echo e(route('suasanp',$product->id)); ?>" method="POST">
      <?php echo e(csrf_field()); ?>

      <fieldset>
        <!-- Form Name -->
        <legend>CHỈNH SỬA SẢN PHẨM</legend>

        <div style="display: flex;margin-top: 40px;">
        <!-- Text input-->
        <div >
        <div class="form-group">
          <div style="display:flex">
          <label class="col-md-4 control-label" for="product_name">TÊN</label>
          <div class="col-md-4" style="width:400px">
            <input id="product_name" name="ten" value="<?php echo e($product->title); ?>" placeholder="TÊN" class="form-control input-md" required="" type="text">

          </div>
        </div>
        </div>

        <!-- Select Basic -->
        <div class="form-group">
          <div style="display:flex">
          <label class="col-md-4 control-label" for="product_categorie"> LOẠI</label>
          <div class="col-md-4"style="width:400px">
            <div style="display:flex">
            <select id="product_categorie" name="loai" class="form-control" >
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($category->id == $product->id_type): ?>
                    <option selected value=<?php echo e($category->id); ?>> <?php echo e($category->type); ?></option>
                <?php else: ?>
                    <option value=<?php echo e($category->id); ?>> <?php echo e($category->type); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          </div>
        </div>
        </div>
        <!-- Text input-->
        <div class="form-group">
          <div style="display:flex">
          <label class="col-md-4 control-label" for="product_weight">GIÁ</label>
          <div class="col-md-4"style="width:400px">
            <input id="product_weight" name="gia" value="<?php echo e($product->unit_price); ?>" placeholder="GIÁ" class="form-control input-md" required="" type="text">
          </div>
        </div>
        </div>

        <div class="form-group">
          <div style="display:flex">
          <label class="col-md-4 control-label" for="product_weight">GIÁ GIẢM</label>
          <div class="col-md-4" style="width:400px">
            <input id="product_weight" name="giagiam" value="<?php echo e($product->promotion_price); ?>" placeholder="GIÁ GIẢM" class="form-control input-md" required="" type="text">
          </div>
        </div>
        </div>
      </div>
      <div>

        <div class="form-group">
          <div style="display:flex">
          <label class="col-md-4 control-label" for="product_weight">SỐ LƯỢNG</label>
          <div class="col-md-4" style="width:400px">
          <input id="product_weight" name="soluong"value="<?php echo e($product->quantity); ?>"  placeholder="SỐ LƯỢNG" class="form-control input-md" required="" type="text">
          </div>
        </div>
        </div>
        <!-- Textarea -->
        <div class="form-group">
          <div style="display:flex">
          <label class="col-md-4 control-label" for="product_description">MÔ TẢ</label>
          <div class="col-md-4" style="width:400px">
            <textarea class="form-control" id="product_description" name="mota">
              <?php echo e($product->description); ?>

            </textarea>
          </div>
        </div>
        </div>

        <!-- Text input-->
        


        <!-- File Button -->
        <div class="form-group">
          <div style="display:flex">
          <label class="col-md-4 control-label" for="filebutton">THÊM ẢNH</label>
          <div class="col-md-4">
            <input id="filebutton" name="myFile" class="input-file" type="file">
          </div>
        </div>
        </div>

                <!-- Button -->
                <div class="form-group">
                  <label class="col-md-4 control-label" for="singlebutton"></label>
                  <div class="col-md-4">
                    <button id="singlebutton" name="singlebutton" class="btn btn-primary">LƯU</button>
                  </div>
                </div>
      </div>
    </div>


      </fieldset>
    </form>

    <!-- /.container-fluid -->
  </div>
  <footer class="footer text-center"> 2017 &copy; Ample Admin brought to you by wrappixel.com </footer>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../admin/masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Huong_React\foodBrother\foodBrother\resources\views/admin/pageAdmin/editProduct.blade.php ENDPATH**/ ?>