
<nav class="navbar navbar-default navbar-static-top m-b-0">
    <div class="navbar-header">
        <div class="top-left-part">
            <a class="logo" href="admin.html">
                <b>
                    <a>Food restaurent</a>
                </b>
            </a>
        </div>
        <ul class="nav navbar-top-links navbar-right pull-right">
            <li>
                <a class="nav-toggler open-close waves-effect waves-light hidden-md hidden-lg" href="javascript:void(0)"><i class="fa fa-bars"></i></a>
            </li>
            <li>
                <form role="search" class="app-search hidden-sm hidden-xs m-r-10">
                    <input type="text" placeholder="Search..." class="form-control">
                    <a href="">
                        <i class="fa fa-search"></i>
                    </a>
                </form>
            </li>
            <li>
                <a class="profile-pic" href="#"> <img src="public/img_food/anh.jpg" alt="user-img" width="36" class="img-circle"><b class="hidden-xs">Anh</b></a>
            </li>
        </ul>
    </div>
</nav>

<?php /**PATH C:\xampp\htdocs\foodBrother\resources\views////components/headerAdmin.blade.php ENDPATH**/ ?>