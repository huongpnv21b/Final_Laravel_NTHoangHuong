;
<?php $__env->startSection('content'); ?>;
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 col-lg-12 col-sm-12">
                <div class="white-box">
                    <div class="col-md-3 col-sm-4 col-xs-6 pull-right">
                        <select class="form-control pull-right row b-none" id="sel">
                            <option >Tất cả sản phẩm</option>
                            <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value=<?php echo e($type->id); ?> onclick="select()"><?php echo e($type->type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                   <div class="row">
                        <button class="btn" onclick="displayProduct()">sản phẩm</button>
                        <button class="btn" onclick="displayCustomer()">Khách hàng</button>
                   </div>
                    <div class="table-responsive product" id="product">
                        <table class="table">
                            <thead>
                              <tr>
                                <th scope="col">#</th>
                                <th scope="col">Tên sản phẩm</th>
                                <th scope="col">giá</th>
                                <th scope="col">Loại sản phẩm</th>
                                <th scope="col">img</th>
                                <th scope="col">option</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+1); ?></th>
                                    <td><?php echo e($item->title); ?></td>
                                    <td><?php echo e($item->unit_price); ?></td>
                                    <td><?php echo e($item->id_type); ?></td>
                                    <td><img src="<?php echo e($item->image); ?>" alt="" style="width: 50px; height:50px"></td>
                                    <td>
                                        <div style="display: flex;">
                                            <form method="POST" action="">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo method_field('UPDATE'); ?>
                                                
                                                <a href="<?php echo e(route('xoasanpham',$item->id)); ?>" class="btn btn-danger" type="submit">Xóa</a>
                                                <a href="<?php echo e(route('suasanp',$item->id)); ?>" class="btn btn-danger">Sửa</a>

                                            </form>
                                        </div>
                                    </td>
                                  </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                          </table>
                        <button class="btn"><a href="<?php echo e(route('export')); ?>">Export</a></button>
                        <button class="btn">Import</button>
                    </div>
                    <div class="table-responsive customer" id="customer" style="display: none">
                        <table class="table">
                            <thead>
                              <tr>
                                <th scope="col">#</th>
                                <th scope="col">name</th>
                                <th scope="col">address</th>
                                <th scope="col">phone</th>
                              </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                          </table>
                          <button class="btn">Export</button>
                        <button class="btn">Import</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
    <footer class="footer text-center"> 2017 &copy; Ample Admin brought to you by wrappixel.com </footer>
</div>
<script>
    function select(){
        var e = document.getElementById("sel");
        var strUser = e.options[e.selectedIndex].value;
        console.log(strUser);
    }

    function displayProduct(){
        document.getElementById("product").style.display="block";
        document.getElementById("customer").style.display="none";
    }
    function displayCustomer(){
        document.getElementById("product").style.display="none";
        document.getElementById("customer").style.display="block";
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../../admin/masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Huong_React\foodBrother\foodBrother\resources\views/admin/pageAdmin/tableAdmin.blade.php ENDPATH**/ ?>