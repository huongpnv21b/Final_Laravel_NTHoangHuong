<!DOCTYPE html>
<html lang=""<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"">

<head>
    <meta charset="utf-8">
    <base href="<?php echo e(asset('')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="public/img_food/logo.png">
    <title>Ample Admin Template - The Ultimate Multipurpose admin template</title>
    <link href="public/css/bootstrap.min.css" rel="stylesheet">
    <link href="public/css/style.css" rel="stylesheet">
    <script src="public/js/chart.js/Chart.min.js"></script>

</head>

<body class="fix-header">
    <div id="wrapper">
        <?php echo $__env->make('../components/headerAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        <?php echo $__env->make('../components/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>;
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Huong_React\foodBrother\foodBrother\resources\views///////admin/masterAdmin.blade.php ENDPATH**/ ?>